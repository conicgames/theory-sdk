# Exponential Idle - Theory SDK
Theory SDK for the mobile game [Exponential Idle](https://conicgames.github.io/exponentialidle/)

WIP
